#include<iostream>
using namespace std;
namespace N1
{
    int no1=500;
    int no2=600;
    namespace N2
    {
        int no1=1000;
        int no3=1100;
    }
}
int no1=100; // global 
using namespace N1;
using namespace N2;
//using namespace N1::N2;
int main(void)
{
    int no1=10; // local
    cout<<" N1::N2::no1="<<N1::N2::no1<<endl;  //1000
    cout<<" N1::N2::no3="<<N1::N2::no3<<endl;  // 1100
    cout<<"no1="<<no1<<endl; //no1=10
    cout<<" N1::N2::no3="<<no3<<endl; // no3=1100
    cout<<" ans="<< ::no1 + no1 - N1::N2::no1<<endl;
                  //100   + 10  - 1000 == -890  
    cout<<" ans="<< ::no1 + no1 -( N1::N2::no1/ N1::no1) <<endl;
                 // 100   + 10  -(1000/500)  ==  108



    return 0;
}