#include<iostream>
using namespace std;
class Complex
{
    private:
        int real;
        int imag;
    public:
        void print()
        {
            cout<<"this->real="<<this->real<<"\t ["<<&this->real<<"]"<<endl;
            cout<<"this->real="<<this->imag<<"\t ["<<&this->imag<<"]"<<endl;
        }   
        // parameterless ctor or no arg ctor
        Complex()
        {
            this->real=10;
            this->imag=20;
            cout<<"inside parameterless ctor"<<endl;
        }

        // parameterized ctor with 1 arg
        Complex(int value)
        {
            this->real=value;
            this->imag=value;
            cout<<"inside parameterized ctor with 1 arg ctor"<<endl;
        }
        // parameterized ctor with 2 arg
        Complex(int real, int imag)
        {
            this->real=real;
            this->imag=imag;
            cout<<"inside parameterized ctor with 2 arg ctor"<<endl;
        }
        //className ( const ClassName& other)
        Complex( const Complex&other)
        {
            //&c2           // other is new name for c1
            this->real= other.real;
            this->imag= other.imag;
            cout<<"inside copy ctor ctor"<<endl;
        }
        ~Complex()
        {
            cout<<"==============="<<endl;
            this->print();
            cout<<"==============="<<endl;
            this->real=0;
            this->imag=0;
            cout<<"inside dtor "<<endl;
        }
};

int main(void)
{ 
    Complex c1(11,22);
    cout<<"c1="<<endl;
    c1.print();
// when we assign allready created object (c1) to newly created obejct (c2)
// iternally copy ctor called
   // 
   Complex c2(c1);  //Complex c2= c1;   // copy ctor c2;
   cout<<"c2="<<endl;
   c2.print();

   
    return 0;
}