#include<iostream>
using namespace std;
class Demo
{
    private:
        int &r1;
        char &r2;
        float &r3;
        double &r4;
    public:
};
int main(void)
{
    cout<<"sizeof(Demo)="<<sizeof(Demo)<<endl;  // 32 bit  4*4=16
                                                 // 64 bit 8*4=32
    return 0;
}
// g++ -m32 demo2_5.cpp  for 32 bit
// g++ -m64 demo2_5.cpp  for 64 bit

/*
int *ptr=NULL;  // 4 bytes 32 bit or 8 bytes on 64 bit
char *ptr1=NULL;  // 4 bytes 32 bit or 8 bytes on 64 bit
float *ptr2=NULL;  // 4 bytes 32 bit or 8 bytes on 64 bit
double *ptr=NULL;  // 4 bytes 32 bit or 8 bytes on 64 bit

int n1; // 4
char ch; //1
float f1;// 4
double d1;// 8

by default 32 bit compilation

*/
