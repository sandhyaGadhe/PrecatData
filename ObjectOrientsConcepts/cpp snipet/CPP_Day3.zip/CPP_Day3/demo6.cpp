/* 1 default ctor
   2 parameterless ctor / no arg ctor
   3 parameterized ctor
      1. copy ctor
  */
#include<iostream>
using namespace std;
class Complex
{
    private:
        int real;
        int imag;
    public:
        void print()
        {
            cout<<"this->real="<<this->real<<endl;
            cout<<"this->real="<<this->imag<<endl;
        }        
};
Complex c2;
int main(void)
{
    Complex c1; // local
    cout<<"c1="<<endl;
    c1.print(); // real= garbage imag= garbage

    cout<<"c2="<<endl;
    c2.print(); // real=0 imag= 0


    static Complex c4; // static 
    cout<<"c4="<<endl;
    c4.print(); // real=0 imag= 0

    return 0;
}