#include<stdio.h>
struct emp
{

};

int main()
{        //old name    new
    typedef struct emp EMP;

    typedef char* ptr;
    ptr  p1,p2;
    char *p3, p4;
    printf("\n p1=%d", sizeof(p1));
    printf("\n p2=%d", sizeof(p2));

    struct emp e1,e2;
    EMP e3, e4;
}