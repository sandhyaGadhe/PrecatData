#include<stdio.h>
int no1=100; // global 
int main(void)
{
    int no1=10; // local
    printf("\n no=%d [%u]", no1, &no1); // no1=10
    return 0;
}