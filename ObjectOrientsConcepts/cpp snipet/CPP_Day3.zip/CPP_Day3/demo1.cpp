#include<stdio.h>
int no1=100; // global 
int main(void)
{
    int no1=10; // local
    printf("\n local varible no=%d [%u]", no1, &no1); // no1=10
    printf("\n global variable ::no=%d [%u]", ::no1, &::no1); // no1=100
    return 0;
}