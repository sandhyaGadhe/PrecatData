#include<stdio.h>
namespace N1
{
    int no1=500;
    int no2=600;
}
int no1=100; // global 
int main(void)
{
    int no1=10; // local
    printf("\n local varible no=%d [%u]", no1, &no1); // no1=10
    printf("\n global variable ::no=%d [%u]", ::no1, &::no1); // no1=100

    printf("\n N1::no1=%d [%u]",N1::no1, &N1::no1); // no1=500

    printf("\n N1::no2=%d [%u]",N1::no2, &N1::no2); // no2=600

    using namespace N1;
    printf("\n no2=%d [%u]",no2, &no2); // no2=600
    printf("\n no1=%d [%u]",no1, &no1); // no1=10
    printf("\n N1::no1=%d [%u]",N1::no1, &N1::no1); // no1=500


    return 0;
}