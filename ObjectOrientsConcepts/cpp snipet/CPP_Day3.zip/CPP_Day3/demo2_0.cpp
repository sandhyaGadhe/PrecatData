#include<iostream>
using namespace std;
int main(void)
{
   
    int a=10; // variable/// object
    int &r=a; // r is a reference of a
 // int *const r=&a;    ref is a constant pointer which automattically dereferecnce
 // for pointers we have to use value at operator *
    cout<<"a="<<a<<"\t &a="<<&a<<endl; //10
    cout<<"r="<<r<<"\t &r="<<&r<<endl; //10

    a=100;
    cout<<"a="<<a<<"\t &a="<<&a<<endl; //100
    cout<<"r="<<r<<"\t &r="<<&r<<endl; //100

    r=1000;
    cout<<"a="<<a<<"\t &a="<<&a<<endl; //1000
    cout<<"r="<<r<<"\t &r="<<&r<<endl; //1000

    a++;
    cout<<"a="<<a<<"\t &a="<<&a<<endl; //1001
    cout<<"r="<<r<<"\t &r="<<&r<<endl; //1001

    r++;
    cout<<"a="<<a<<"\t &a="<<&a<<endl; //1002
    cout<<"r="<<r<<"\t &r="<<&r<<endl; //1002




    return 0;
}