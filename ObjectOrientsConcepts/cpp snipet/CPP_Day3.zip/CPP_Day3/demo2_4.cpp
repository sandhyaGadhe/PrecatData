#include<iostream>
using namespace std;
int main(void)
{
   
    const int a=10; // variable/// object
    const int &r=a; // r is a reference of a
   // const int * const r=&a;
    // error: binding reference of type ‘int&’ to ‘const int’ discards qualifiers
    
    cout<<"a="<<a<<"\t &a="<<&a<<endl; //10
    cout<<"r="<<r<<"\t &r="<<&r<<endl; //10

    //a=100;  //error as a is const
    // r=1000;//error as ref is const


    return 0;
}