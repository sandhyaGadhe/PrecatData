#include<iostream>
using namespace std;
int main(void)
{
    int a=10; // variable/// object
    const int &r=a; // r is a reference of 
// const int *const r=&a;
    
    cout<<"a="<<a<<"\t &a="<<&a<<endl; //10
    cout<<"r="<<r<<"\t &r="<<&r<<endl; //10

    a=100;
    cout<<"a="<<a<<"\t &a="<<&a<<endl; //100
    cout<<"r="<<r<<"\t &r="<<&r<<endl; //100

   // r=1000; ///error
    return 0;
}