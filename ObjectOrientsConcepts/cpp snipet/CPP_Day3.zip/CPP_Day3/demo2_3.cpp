#include<iostream>
using namespace std;
int main(void)
{
   
    const int a=10; // variable/// object
    int &r=a; // r is a reference of a
    // error: binding reference of type ‘int&’ to ‘const int’ discards qualifiers
    
   

    return 0;
}