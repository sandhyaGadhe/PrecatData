#include<iostream>
using namespace std;
int main(void)
{
    {
        int no1=10;
        int *ptr=&no1;
        cout<<" no1="<<no1<<"\t *ptr="<<*ptr<<endl;

        *ptr=100;
        cout<<" no1="<<no1<<"\t *ptr="<<*ptr<<endl;

        no1=200;
        cout<<" no1="<<no1<<"\t *ptr="<<*ptr<<endl;
    }
    return 0;
}