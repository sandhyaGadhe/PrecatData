#include<iostream>
using namespace std;
class Complex
{
    private:
        int real;
        int imag;
    public:
        void print()
        {
            cout<<"this->real="<<this->real<<"\t ["<<&this->real<<"]"<<endl;
            cout<<"this->real="<<this->imag<<"\t ["<<&this->imag<<"]"<<endl;
        }   
        // parameterless ctor or no arg ctor
        Complex()
        {
            this->real=10;
            this->imag=20;
            cout<<"inside parameterless ctor"<<endl;
        }

        // parameterized ctor with 1 arg
        Complex(int value)
        {
            this->real=value;
            this->imag=value;
            cout<<"inside parameterized ctor with 1 arg ctor"<<endl;
        }
        // parameterized ctor with 2 arg
        Complex(int real, int imag)
        {
            this->real=real;
            this->imag=imag;
            cout<<"inside parameterized ctor with 2 arg ctor"<<endl;
        }
        ~Complex()
        {
            cout<<"==============="<<endl;
            this->print();
            cout<<"==============="<<endl;
            this->real=0;
            this->imag=0;
            cout<<"inside dtor "<<endl;
        }
};

int main(void)
{
    Complex c1; // parameterless
    cout<<"c1="<<endl;
    c1.print(); // real= 10 imag= 20

    Complex c2(111); // parameterized ctor with 1 arg ctor
    cout<<"c2="<<endl;
    c2.print(); // real= 111 imag= 111

    Complex c3(567,890); // parameterized ctor with 2 arg ctor
    cout<<"c3="<<endl;
    c3.print(); // real= 567 imag= 890

    return 0;
}
/* for local objects
stack   [FILO  / LIFO]
[c3]
[c2]
[c1]

ctor  dtor
c1     c3
c2     c2
c3     c1
*/