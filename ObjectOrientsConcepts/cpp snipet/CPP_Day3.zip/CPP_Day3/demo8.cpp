#include <stdio.h>
int main() 
{
    printf("cdac ");
    main();
    return 0;
} // run time error (stack over flow)