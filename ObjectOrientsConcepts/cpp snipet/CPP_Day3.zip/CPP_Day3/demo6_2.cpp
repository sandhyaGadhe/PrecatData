#include<iostream>
using namespace std;
class Complex
{
    private:
        int real;
        int imag;
    public:
        void print()
        {
            cout<<"this->real="<<this->real<<endl;
            cout<<"this->real="<<this->imag<<endl;
        }   
       
        // parameterized ctor with 2 arg with defualt arg
        Complex(int real=10, int imag=20)
        {
            this->real=real;
            this->imag=imag;
            cout<<"inside parameterized ctor with 2 arg ctor"<<endl;
        }
};

int main(void)
{
    Complex c1; // parameterless
    cout<<"c1="<<endl;
    c1.print(); // real= 10 imag= 20

    Complex c2(111); // parameterized ctor with 1 arg ctor
    cout<<"c2="<<endl;
    c2.print(); // real= 111 imag= 20

    Complex c3(567,890); // parameterized ctor with 2 arg ctor
    cout<<"c3="<<endl;
    c3.print(); // real= 567 imag= 890

    return 0;
}