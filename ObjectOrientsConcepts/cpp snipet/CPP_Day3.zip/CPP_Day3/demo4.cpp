#include<iostream>
using namespace std;
int main(void)
{
    int no1=10, no2=0, ans=0;

    try
    {
        if( no2==0)
            //throw 1.2;  // double
            throw 1;  // int
        ans= no1/no2;
        cout<<"ans="<<ans<<endl;
    } 
    catch(int)
    {
        cout<<"inside int block1"<<endl;
        cout<<"con not divide by zero"<<endl;
    }
    catch(int)
    {
        cout<<"inside int block2"<<endl;
        cout<<"con not divide by zero"<<endl;
    }
    catch(float)
    {
        cout<<"inside float block"<<endl;
        cout<<"can not divide by zero"<<endl;
    }
    catch(double)
    {
        cout<<"inside double block"<<endl;
        cout<<"can not divide by zero"<<endl;
    }
    catch(...) // ellipse generic catch should be last in exception handling
    {
        cout<<"inside generic block"<<endl;
        cout<<"can not divide by zero"<<endl;
    }
    
    return 0;
}