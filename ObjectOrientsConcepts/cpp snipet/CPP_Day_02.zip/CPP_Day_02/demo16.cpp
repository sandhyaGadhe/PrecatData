// we can write member function out side class
#include<iostream>
using namespace std;
class Complex
{
    private:
        int real;
        int imag;
    public:
        void display();
    
};
//return_type_fun className::Member_Fun_Name(data_type var_name);
void Complex::display()
{
    cout<<this->real;
    cout<<this->imag;
}
int main()
{
    Complex c1;
    c1.display();
    return 0;
}
