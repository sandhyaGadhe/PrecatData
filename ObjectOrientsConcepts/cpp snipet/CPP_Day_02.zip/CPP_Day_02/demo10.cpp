#include<iostream>
using namespace std;
int main(int argc , char *argv[], char *envp[])
{
    int a=5;
    int &b=a;
    int c=10;
    b=c;
    cout<<a<< " "<<b<<endl;  //10 10
    c=20;
    cout<<a<< " "<<b<<endl;//  10 10
    return 0;
}

/* const classname * const this
 const student * const this


sum();
sum(10,20);
sum(10);
sum(10,20,30);

int sum(int a, int b, int c=0);
int sum(int a, int b=0, int c=0);
int sum(int a=0, int b=0, int c=0);
int sum(int a=0, int b, int c=0); // error

// this---> all memebr fun except static member fun

function which dont have this pointer
//1. global function  2. friend function  3. static member fun
 */