#include<iostream>
using namespace std;
class ConstDemo
{
    private:
        const int  a;
        static int counter;
    public:
        ConstDemo():a(10)
        {  // ctor init list
            
        }
        ConstDemo(int a):a(a)
        {
            
        }
        void display()
        {
            cout<<" counter=" <<ConstDemo::counter<<endl;
        }
}; 
int ConstDemo::counter=100;  //global defination of static data member
//int ConstDemo::counter;  //int ConstDemo::counter=0;
int main(void)
{
    ConstDemo c1;
    c1.display();
    return 0;
}