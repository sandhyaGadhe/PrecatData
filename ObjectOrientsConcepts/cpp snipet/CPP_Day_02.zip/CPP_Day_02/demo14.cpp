#include<iostream>
using namespace std;
int main()
{
  int *p = new int(11);
  cout<<"*p="<<*p<<endl;
  delete p;
  delete p; 
  
  return 0;
} // error --> //double free detected in tcache 2 Aborted (core dumped)
