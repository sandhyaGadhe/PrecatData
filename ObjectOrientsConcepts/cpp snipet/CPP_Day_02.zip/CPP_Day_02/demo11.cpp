#include<stdio.h>
int main(void)
{
    const float pi=3.142F;
    //float *ptr=&pi; //error
   float  const *  ptr=&pi; //allowed

    //const float *ptr=&pi; //allowed
                         //    3.142  3.142
    printf("\n pi=%.3f *ptr=%.3f",pi, *ptr); 
    //*ptr=4.14f;             //3.142  3.142
    //error value of pointer is constant
    printf("\n pi=%.3f *ptr=%.3f",pi, *ptr); 
    return 0;

}
//we can not modify value of constant using pointer in cpp
