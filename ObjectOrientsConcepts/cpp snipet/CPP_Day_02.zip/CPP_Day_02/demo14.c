/*#include<stdio.h>
extern int i;
int main(void)
{
    printf("\n i=%d", i);
    return 0;
}int i;
*/
#include<stdio.h>
int i=10;
int main(void)
{
    printf("\n i=%d", i);
    return 0;
}
extern int i;