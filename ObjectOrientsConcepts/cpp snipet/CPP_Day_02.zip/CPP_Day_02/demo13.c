#include<stdio.h>
extern int i;
int main(void)
{
    printf("\n i=%d", i);
    return 0;
}