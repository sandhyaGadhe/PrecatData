#include<stdio.h>
int main(void)
{
    const float pi=3.142F;
    float *ptr=&pi;
                         //    3.142  3.142
    printf("\n pi=%.3f *ptr=%.3f",pi, *ptr); 
    *ptr=4.14f;             //4.140   4.140
    printf("\n pi=%.3f *ptr=%.3f",pi, *ptr); 
    return 0;

} //we can modify value of constant using pointer in c