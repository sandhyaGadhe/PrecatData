#include<iostream>
using namespace std;
class Complex
{
    private:
        int real;
        int imag;
    public:
    void display()
    {
        cout<<this->real;
        cout<<this->imag;
    }

};
int main()
{
    Complex c1;
    c1.display();
    return 0;
}
