// we can write memeber fun defination outside class using :: operator
// return_type class_name::member_funtion_name(datatype par1);

#include<iostream>
using namespace std;
class FriendDemo
{
    private:
        int a;
        int b;
    public:
    // decl of member function
    FriendDemo();
    FriendDemo(int a, int b);
    void print();
    ~FriendDemo();
    friend void sum(); 
    // friend fun can access private/ public/ proctected data out side class
};
    FriendDemo::FriendDemo()
    {
        this->a=10;
        this->b=20;
    }
    FriendDemo:: FriendDemo(int a, int b)
    {
        this->a=a;
        this->b=b;
    }
    void FriendDemo::print()
    {
        cout<<"this->a="<<this->a<<endl;
        cout<<"this->b="<<this->b<<endl;
    }
    FriendDemo::~FriendDemo()
    {
        this->a=0;
        this->b=0;
    }

void sum()
{
    FriendDemo obj1;
    int ans= obj1.a + obj1.b;
    cout<<"ans="<<ans<<endl;
    return ;
}

int main(void)
{
    cout<<"member fun defination outside class"<<endl;
    sum();
    return 0;
}