#include<iostream>
using namespace std;
#define sq(a) a*a   // macro is command
#define sq1(a) (a)*(a) 
inline int square(int a); // inline is a request
int main(void)
{
    int x=5, y=0;
    y= sq1(x+x);  // y= (x+x)*(x+x) == 10*10=100
    cout<<"x="<<x<<"\t y="<<y<<endl; //x=5 y=25

    y= sq(x);  // y= 5*5=25
    cout<<"x="<<x<<"\t y="<<y<<endl; //x=5 y=25

    y= sq(x+x);  // y= x+x*x+x  y= 5+5*5+5 y= 5+25+5 = 35
    cout<<"x="<<x<<"\t y="<<y<<endl;//x=5 y=35

    y= sq((x+x));  // y= (x+x)*(x+x)  y= (5+5)*(5+5) y= 10*10 = 100
    cout<<"x="<<x<<"\t y="<<y<<endl;//x=5 y=100

    y= 25/sq(x); //   25/x*x   25/5*5  5*5
    cout<<"x="<<x<<"\t y="<<y<<endl;//x=5 y=25
    
    y=square(x);  // y=  a*a;
    cout<<"x="<<x<<"\t y="<<y<<endl;//x=5 y=25

    return 0;
}
inline int square(int a) 
{
    return a*a;
}
