#include<iostream>
using namespace std;

class Base
{
    private:
        int a; 
        int b;
    public:
        Base()
        {
            this->a=0;
            this->b=0;
            cout<<"inside parameterless ctor of Base"<<endl;

        }
        Base(int a, int b)
        {
            this->a=a;
            this->b=b;
            cout<<"inside parameterized ctor of Base"<<endl;        
        }
        virtual void print()
        {
            cout<<"inside base class"<<endl;
            cout<<"this->a =" <<this->a<<endl;
            cout<<"this->b =" <<this->b<<endl;
        }
        ~Base()
        {
            this->a=0;
            this->b=0;
            cout<<"inside dtor of base"<<endl;
        }

}; // end of class Base
class Derived : public Base
{
    private:
        int c; 
     public:
        Derived()
        {
            this->c=0;
            cout<<"inside parameterless ctor of Derived"<<endl;

        }
        Derived(int a, int b, int c):Base(a, b)
        {
            this->c=c;
            cout<<"inside parameterzied ctor of Derived"<<endl;
        }
        void print()
        {
              cout<<"inside Derived class"<<endl;
            Base::print();
            cout<<"this->c =" <<this->c<<endl;

        }
        ~Derived()
        {
            this->c=0;
            cout<<"inside dtor of Derived"<<endl;
        }

}; // end of class Derived

int main(void)
{
    Base *ptrBase1= new Derived(11,22,33);  // upcasting
    ptrBase1->print();  // Derived class Print

    delete ptrBase1;
    ptrBase1=NULL;

    return 0;
}