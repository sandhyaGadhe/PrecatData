#include<iostream>
using namespace std;
class ConstDemo
{
    private:
        int a;
        const int b;
    public:
        ConstDemo():a(10), b(20)
        {
             //this->a=20; // allowed
             //this->b=20; // error as b is const  
        }
        ConstDemo(int a, int b):a(a), b(b)
        {
             //this->a=a; // allowed
             //this->b=b; // error as b is const 
        }       
        // non constant member fun
        void print() 
        {
            this->a=30; // allowed
            cout<<"this->a="<<this->a<<endl;
            cout<<"this->b="<<this->b<<endl;
        }
        // we can not modify state of the object in const mem fun of class
        void display()const
        {
           // this->a=30; not allowed as member fun is const
            cout<<"this->a="<<this->a<<endl;
            cout<<"this->b="<<this->b<<endl;
        }

        // return_type mem_function_name(data_type parameters)const
};
int main()
{
    ConstDemo c1;  // non const object
    cout<<"c1 display"<<endl; 
    c1.display();  // a=10  b=20
    
    cout<<"c1 print"<<endl;
    c1.print();  // a=30  b=20
    return 0;
}
// non const object c1 can call const member function (display)
// non const object c1 can call non const member function ( print)
