#include<iostream>
using namespace std;
class Chair
{
    private:
        int height;
        static float price;
    public:
        Chair()
        {
            this->height=5;
        }
        void print()
        {
            cout<<" this->height="<<this->height<<"["<< &this->height<< "]"<<endl;
            cout<<" Chair::height="<<Chair::price<<"["<< &Chair::price<< "]"<<endl;
        }
};
// size of the obejct is sum of the size non static data member
int main(void)
{
    Chair c1;
    cout<<"c1="<<endl;
    c1.print();
    return 0;
}
// undefined reference to `Chair::price' error