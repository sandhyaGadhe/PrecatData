#include<iostream>
using namespace std;
class FriendDemo
{
    private:
        int a;
        int b;
    public:
    FriendDemo()
    {
        this->a=10;
        this->a=20;
    }
    FriendDemo(int a, int b)
    {
        this->a=a;
        this->a=b;
    }
    void print()
    {
        cout<<"this->a="<<this->a<<endl;
        cout<<"this->b="<<this->b<<endl;
    }
    ~FriendDemo()
    {
        this->a=0;
        this->b=0;
    }
};

void sum()
{
    FriendDemo obj1;
    int ans= obj1.a + obj1.b;
    cout<<"ans="<<ans<<endl;
    return ;
}

int main(void)
{
    sum();
    return 0;
}
// ‘int FriendDemo::a’ is private within this context
// ‘int FriendDemo::b’ is private within this context