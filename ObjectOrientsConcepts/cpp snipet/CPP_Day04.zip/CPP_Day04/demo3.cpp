#include<iostream>
using namespace std;
#define SWAP(n1, n2 , DataType) { DataType temp; temp=n1 ; n1=n2; n2=temp;}
int main(void)
{
    {
        int x=10, y=20;
        cout<<"before swap x="<<x<<"\t y="<<y<<endl;
        SWAP(x, y, int);
        cout<<"after swap x="<<x<<"\t y="<<y<<endl;
    }
    cout<<"==================="<<endl;
    {
        float x=10.2, y=20.1;
        cout<<"before swap x="<<x<<"\t y="<<y<<endl;
        SWAP(x, y, float);
        cout<<"after swap x="<<x<<"\t y="<<y<<endl;
    }
    cout<<"==================="<<endl;
    {
        char x='A', y='B';
        cout<<"before swap x="<<x<<"\t y="<<y<<endl;
        SWAP(x, y, char);
        cout<<"after swap x="<<x<<"\t y="<<y<<endl;
    }
    return 0;
}