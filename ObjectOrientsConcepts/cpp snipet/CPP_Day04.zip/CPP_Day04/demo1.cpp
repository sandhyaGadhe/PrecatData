#include<iostream>
using namespace std;
#define char_ptr  char* 
typedef char* ptr_c;
int main(void)
{
    char_ptr c1, c2;  
    // char *c1, c2;
    ptr_c c3, c4;

    cout<<"size of c1="<<sizeof(c1)<<endl;  // 4 (32  bit) or 8(64 bit) bytes
    cout<<"size of c2="<<sizeof(c2)<<endl;  // 1 bytes

    cout<<"size of c3="<<sizeof(c3)<<endl;  // 4 (32  bit) or 8(64 bit) bytes
    cout<<"size of c4="<<sizeof(c4)<<endl;  //  4 (32  bit) or 8(64 bit) bytes

    return 0;
} // 4    1   4  4   32 bit /  8  1  8 8  64 bit

// to create a .i file ---->  g++ -E -o demo1.i demo1.cpp
//                            gcc -E -o demo1.i demo1.c