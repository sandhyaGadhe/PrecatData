#include<iostream>
using namespace std;

class Base
{
    private:
        int a; 
        int b;
    public:
        Base()
        {
            this->a=0;
            this->b=0;
        }
        Base(int a, int b)
        {
            this->a=a;
            this->b=b;
        }
        void print()
        {
            cout<<"inside base class"<<endl;
            cout<<"this->a =" <<this->a<<endl;
            cout<<"this->b =" <<this->b<<endl;
        }
        ~Base()
        {
            this->a=0;
            this->b=0;
        }

}; // end of class Base
class Derived : public Base
{
    private:
        int c; 
     public:
        Derived()
        {
            this->c=0;
        }
        Derived(int a, int b, int c):Base(a, b)
        {
            this->c=c;
        }
        void print()
        {
              cout<<"inside Derived class"<<endl;
            Base::print();
            cout<<"this->c =" <<this->c<<endl;

        }
        ~Derived()
        {
            this->c=0;
            
        }

}; // end of class Derived

int main(void)
{                                    //a  b
   Base objBase; // parameterless ctor  0 0 
   cout<<"objBase="<<endl;
   objBase.print();  // a=0  b=0
                     //a   b   c
   Derived objDerived(50, 60, 70); // parameterzied ctor  50, 60, 70
   cout<<"objDerived="<<endl;
   objDerived.print();// a=50  b=60  c=70


   objBase= objDerived;  // object slicing
   cout<<"objBase="<<endl;
   objBase.print();// a=50  b=60

    // 3 data member   
    //objDerived= objBase; // ereor
               // 2 data member


    return 0;
}