#include<iostream>
using namespace std;
class Maths
{
    public:
    static int sum(int n1, int n2)
    {
        return n1+n2;
    }
    int minus(int n1, int n2)
    {
        return n1-n2;
    }
}; 

int main(void)
{
    int ans;
    Maths obj1;
    ans= Maths::sum(10,20)  ;
    cout<<"ans= (sum using classname ) "<<ans<<endl;

    //ans=Maths::minus(10,20);  // error
    ans= obj1.minus(10,20)  ;
    cout<<"ans= (minus using  object) "<<ans<<endl;

    ans= obj1.sum(10,20)  ;
    cout<<"ans= (sum using object name) "<<ans<<endl;

    return 0;

}
