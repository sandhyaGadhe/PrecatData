#include<iostream>
using namespace std;
class Chair
{
    private:
        int height;
        static float price;
    public:
        Chair()
        {
            this->height=5;
        }
        Chair(int height)
        {
            this->height=height;
        }
        void print()
        {
            cout<<" this->height="<<this->height<<"\t["<< &this->height<< "]"<<endl;
            cout<<" Chair::height="<<Chair::price<<"\t["<< &Chair::price<< "]"<<endl;
        }
};
// global defination for static data member
float Chair::price=5010.33;
// size of the obejct is sum of the size non static data member
int main(void)
{
    Chair c1,c2(6);
    cout<<"c1="<<endl;
    c1.print();
    cout<<"c2="<<endl;
    c2.print();
    cout<<"size of c1="<<sizeof(c1)<<endl; //4 bytes
    return 0;
}
