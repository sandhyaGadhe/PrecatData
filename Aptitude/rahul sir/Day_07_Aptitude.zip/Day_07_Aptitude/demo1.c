#include<stdio.h>
typedef union testUnion
{
    short int num;              // 2 bytes
    unsigned char ch[2];        // 2 bytes
}TESTUNION;
typedef union testUnion TESTUNION;
int main()
{
    TESTUNION ut; 
    ut.num=639;
    printf("\n %u %u %u\n", &ut.num, &ut.ch[0] , &ut.ch[1]);
    printf("ut.ch[0]=%d\n", ut.ch[0]+1); // 127+1=128
    printf("ut.ch[1]=%d\n", ut.ch[1]-1); // 2-1  =1
    return 0;
}                   
// 639    0000 0010 0111 1111
//            ch[1]   ch[0]  127+1=128
//            2-1=1 
/*
A. 127 4
B. 128 2
C. 127 2
D. 128 3
E. 128 1
Answer: E
*/