#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	int no, tenth, unit;

	printf("\n Enter No :: ");
	scanf("%d", &no);

	unit= no%10;  // 23%10 ==3 
	tenth=no/10; //  23/10 ==2
	switch(tenth)
	{
		case 1: printf(" Ten ");break;
		case 2: printf(" Twenty ");break;
		case 3: printf(" Thirty ");break;
	}//end of tenth switch
	switch(unit)
	{
		case 0: printf(" Zero ");break;
		case 1: printf(" One ");break;
		case 2: printf(" Two ");break;
		case 3: printf(" Three ");break;
	}//end of unit switch
	
	return 0;//return EXIT_SUCCESS;
}// end of main
// 23  Twenty Three


/*
print 1 to 100 roman


Q. The average income of all employees is Rs. 20000. The average salary of male 
employees is Rs. 22000. The average salary of female employees is Rs. 15000. What 
is the ratio of male employees to female employees?

*/