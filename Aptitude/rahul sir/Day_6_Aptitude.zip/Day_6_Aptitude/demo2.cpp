/*
  try in c printf/scanf or cpp (cin/ cout)
1.

#####1
####21
###321
##4321
#54321


2.

#####11
####2112
###321123
##43211234
#5432112345

3.

#####11
####2112
###321123
##43211234
#5432112345
#5432112345
##43211234
###321123
####2112
#####11


4.

#####11
####2112
###321123
##43211234
#5432112345
##43211234
###321123
####2112
#####11

5.
ABCDEDCBA
ABCD DCBA
ABC   CBA
AB     BA
A       A
AB     BA
ABC   CBA
ABCD DCBA
ABCDEDCBA


5.
ABCDEEDCBA
ABCD  DCBA
ABC    CBA
AB      BA
A        A
A        A
AB      BA
ABC    CBA
ABCD  DCBA
ABCDEEDCBA


6. print no into words upto 100
    75  seventy five  (   1 switch case tenth + 1 unit case  )

6. print no into words upto 1000

https://www.youtube.com/watch?v=zSFfxg70R8M   upstream down stream  question

https://youtu.be/FNr28V8zAVM?si=XmHjLl9Md6NNjju_   c question on sunbeam youtube channel

*/