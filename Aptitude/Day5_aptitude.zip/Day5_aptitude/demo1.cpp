/*
1. it is 4 digit number.
1. last digit double of the 1st digit
2. 2ed and 3rd digit of number is same
3. last 2 digits are double of 1st 2 digits
what is the 4 digit no
123 4
XYY2X
====
a  2b

Note- try in using loops in c or cpp*

4998  correct answer

1224  wrong   4 not twice of 1

2994  wrong   half 94   is 47 


=====================================================================

Q
1  2  3         26   27    28   29         256              Col
A  B  C          Z   AA    AB   AC          IV     
                                     256/26=9 256%26=22

===========================================================================

Total should be six

(0!  + 0! +   0!)!  = 6
(1  + 1 +   1)!     = 6
2  +  2 +    2      = 6                               
3  *  3 -    3      = 6                               
sq_root(4) +   sq_root 4)+sq_root(4) = 6
5  /  5  +   5      = 6
6  *  6  /   6      = 6
7  -  7  /   7      = 6 
cube_root(8) +   cube_root(8) +  cube_root(8) = 6
sq_root(9)   *     sq_root(9) -   sq_root(9)  = 6












*/
